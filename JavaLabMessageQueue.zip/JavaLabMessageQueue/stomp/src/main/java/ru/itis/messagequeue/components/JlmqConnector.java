package ru.itis.messagequeue.components;

public class JlmqConnector {

    public JlmqConsumer consumer() {
        return new JlmqConsumer();
    }

}
