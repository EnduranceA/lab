package ru.itis.messagequeue.models;

public enum Status {
    NOT_ACCEPTED, ACCEPTED
}
