package ru.itis.repositories;

import ru.itis.models.JlmqConsumer;

public interface JlmqConsumerRepository extends CrudRepository<Long, JlmqConsumer> {
}
