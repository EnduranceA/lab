package ru.itis.models;

public enum Role {
    USER, ADMIN
}
