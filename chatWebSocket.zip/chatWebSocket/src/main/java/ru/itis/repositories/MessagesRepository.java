package ru.itis.repositories;

import ru.itis.models.Message;

public interface MessagesRepository extends CrudRepository<Long, Message> {
}
