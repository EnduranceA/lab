package ru.itis.repositories;

import ru.itis.models.Room;

public interface RoomRepository extends CrudRepository<Long, Room> {
}
