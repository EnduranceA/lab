package ru.itis.services;

import ru.itis.dto.SignInDto;

public interface SignInService {
    String signIn(SignInDto signInDto);
}
