package ru.itis.repositories;

import ru.itis.models.Message;

public interface MessageRepository extends CrudRepository<Long, Message> {
    void update(Message message);
}
