package ru.itis.models;

public enum State {
    CONFIRMED, NOT_CONFIRMED
}
