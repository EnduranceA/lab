package ru.itis.models;

public enum Role {
    ADMIN, USER, SINGER
}
